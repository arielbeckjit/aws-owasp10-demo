AWS.config.region = 'eu-west-1';
var AWSPoolID = 'eu-west-1:c8ba6dd4-512d-4533-b003-06119ad1533f';
var apiURL = 'https://fpp1p3is76.execute-api.eu-west-1.amazonaws.com/demo';
var bucketName = 'owasp-10';
